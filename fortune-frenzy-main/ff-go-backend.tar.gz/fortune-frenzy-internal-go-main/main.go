package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"

	"ffinternal-go/middleware"
	"ffinternal-go/routes"
	"ffinternal-go/service"
	"ffinternal-go/workers"
	"log"
	"os"

	"github.com/gofiber/fiber/v2"
	"github.com/joho/godotenv"
)

func main() {
	_ = godotenv.Load()

	service.InitMariaDB()
	service.InitRedis()
	app := fiber.New()

	app.Use(middleware.RequestTimer())

	app.Get("/health", func(c *fiber.Ctx) error {
		return c.JSON(fiber.Map{"status": "ok"})
	})

	app.Post("/register/:serverId", func(c *fiber.Ctx) error {
		serverID := c.Params("serverId")
		apiKey := c.Get("x-api-key")
		if serverID == "" || apiKey == "" {
			return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "Missing server ID or API key"})
		}
		redis := service.GetRedisConnection()
		hashedKey := fmt.Sprintf("%x", sha256.Sum256([]byte(apiKey)))
		redis.Set(c.Context(), "api_key:"+serverID, hashedKey, 24*time.Hour)
		redis.Set(c.Context(), "servers:"+serverID+":active", "true", 5*time.Minute)
		return c.JSON(fiber.Map{"status": "OK"})
	})

	app.Post("/packet/:serverId", func(c *fiber.Ctx) error {
		var body struct {
			Packet []struct {
				RequestID string            `json:"request_id"`
				Method    string            `json:"method"`
				Route     string            `json:"route"`
				Headers   map[string]string `json:"headers"`
				Body      json.RawMessage   `json:"body"`
			} `json:"Packet"`
		}
		if err := c.BodyParser(&body); err != nil {
			return c.Status(400).JSON(fiber.Map{"error": "Invalid packet"})
		}

		type packetResponse struct {
			RequestID string `json:"request_id"`
			Response  [2]any `json:"response"`
		}
		responses := make([]packetResponse, 0, len(body.Packet))

		for _, req := range body.Packet {
			httpReq, err := http.NewRequest(req.Method, req.Route, bytes.NewReader(req.Body))
			if err != nil {
				responses = append(responses, packetResponse{RequestID: req.RequestID, Response: [2]any{500, map[string]string{"error": "Bad request"}}})
				continue
			}
			httpReq.Header.Set("Content-Type", "application/json")
			httpReq.Header.Set("packeter-master-key", os.Getenv("PACKETER_BYPASS_KEY"))
			for k, v := range req.Headers {
				httpReq.Header.Set(k, v)
			}
			httpReq.Header.Set("server-id", c.Params("serverId"))

			resp, err := app.Test(httpReq, -1)
			if err != nil {
				responses = append(responses, packetResponse{RequestID: req.RequestID, Response: [2]any{500, map[string]string{"error": "Internal error"}}})
				continue
			}

			respBody, _ := io.ReadAll(resp.Body)
			resp.Body.Close()
			var parsed any
			json.Unmarshal(respBody, &parsed)
			responses = append(responses, packetResponse{RequestID: req.RequestID, Response: [2]any{resp.StatusCode, parsed}})
		}

		return c.JSON(fiber.Map{"status": "OK", "responses": responses})
	})

	routes.SetupSettingsRoutes(app)
	routes.SetupUserRoutes(app)
	routes.SetupMarketplaceRoutes(app)
	routes.SetupCoinflipRoutes(app)
	routes.SetupCaseBattleRoutes(app)
	routes.SetupTradingRoutes(app)
	routes.SetupJackpotRoutes(app)
	routes.SetupItemRoutes(app)
	routes.SetupCaseRoutes(app)
	routes.SetupMiscRoutes(app)

	workers.StartRolimonsWorker()
	workers.StartLeaderboardWorker()

	log.Println("Server is running on port " + os.Getenv("PORT"))
	if err := app.Listen(":" + os.Getenv("PORT")); err != nil {
		log.Fatalf("Error starting server: %v", err)
	}
}
