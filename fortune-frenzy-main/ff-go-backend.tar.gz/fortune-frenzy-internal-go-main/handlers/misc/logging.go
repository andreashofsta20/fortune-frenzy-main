package misc

import (
	"github.com/gofiber/fiber/v2"
)

func NetworkLog(c *fiber.Ctx) error {
	return c.JSON(fiber.Map{
		"status": "OK",
	})
}
